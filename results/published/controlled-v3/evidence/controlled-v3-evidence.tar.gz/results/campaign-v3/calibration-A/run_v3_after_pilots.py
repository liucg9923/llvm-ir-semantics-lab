"""Run the controlled v3 study only after recomputed pilot gates pass."""
from pathlib import Path
import json,time,subprocess,os
from irsem.common import read_json,write_json
from irsem.v3.selection import select
root=Path(__file__).resolve().parents[1];os.chdir(root)
os.environ.update(HF_HOME=str(root/'.cache/huggingface'),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',CUBLAS_WORKSPACE_CONFIG=':4096:8')
start=time.monotonic()
for model in ['compiler-ftd','qwen']:
 p=root/'results/campaign-v3/stages'/('pilot-'+model)/'status.json'
 while True:
  if p.exists():
   s=read_json(p)
   if s['status']=='completed':break
   if s['status']!='running':raise SystemExit('Pilot infrastructure failed: '+model)
  if time.monotonic()-start>10800:raise SystemExit('Pilot wait exceeded')
  time.sleep(2)
pilot_runs=['v3-pilot-compiler-ftd','v3-pilot-qwen']
selected=select(root,pilot_runs)
write_json(root/'results/campaign-v3/flow-state.json',{'status':'primary_accepted' if selected['primary_passed'] else 'primary_gate_failed','selection':selected})
print('PRIMARY_GATES',[(e['model'],e['gate']) for e in selected['primary_evidence']],flush=True)
if not selected['primary_passed']:raise SystemExit('STOP: primary pilot gate failed; no formal model generation was started')
def stage(model,phase,name,out):
 command=['.venv/bin/python','scripts/run_stage.py','--campaign','campaign-v3','--name',name,'--timeout','5400','--profile-gpu','--','flock','.cache/gpu.lock','.venv-inference/bin/python','-m','irsem.v3.runner','--model',model,'--phase',phase,'--out','results/'+out]
 subprocess.run(command,check=True)
for model in ['compiler-ftd','qwen']:stage(model,'hint_pilot','hint-pilot-'+model,'v3-hintpilot-'+model)
selected=select(root,pilot_runs,['v3-hintpilot-compiler-ftd','v3-hintpilot-qwen'])
print('HINT_GATES',[(e['model'],e['gate']) for e in selected['hint_evidence']],flush=True)
for model in ['compiler-ftd','qwen']:
 stage(model,'formal','formal-'+model,'v3-formal-'+model)
 if selected['hint_passed']:stage(model,'hint','hint-'+model,'v3-hint-'+model)
write_json(root/'results/campaign-v3/flow-state.json',{'status':'model_runs_complete','primary_passed':True,'hint_run':selected['hint_passed'],'selection':selected})
print('V3_MODEL_RUNS_COMPLETE',flush=True)
